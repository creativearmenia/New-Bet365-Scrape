# bet365-scraper
Bet365.com scraper, currently scrapes soccer matches but can easily handle data from other games.

Client didn't pay me, so here it is for free. I hope whatever he was scheming is ruined by you.
